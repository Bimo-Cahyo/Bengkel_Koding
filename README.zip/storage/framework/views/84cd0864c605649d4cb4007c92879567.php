<style>
    .main-sidebar {
        background-color: #0600b7 !important;
    }
</style>

<aside class="main-sidebar <?php echo e(config('adminlte.classes_sidebar', 'sidebar-dark-primary elevation-4')); ?>">

    
    <?php if(config('adminlte.logo_img_xl')): ?>
        <?php echo $__env->make('adminlte::partials.common.brand-logo-xl', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php else: ?>
        <?php echo $__env->make('adminlte::partials.common.brand-logo-xs', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php endif; ?>

    
    <div class="sidebar">
        <nav class="pt-2">
            <ul class="nav nav-pills nav-sidebar flex-column <?php echo e(config('adminlte.classes_sidebar_nav', '')); ?>"
                data-widget="treeview" role="menu"
                <?php if(config('adminlte.sidebar_nav_animation_speed') != 300): ?> data-animation-speed="<?php echo e(config('adminlte.sidebar_nav_animation_speed')); ?>" <?php endif; ?>
                <?php if(!config('adminlte.sidebar_nav_accordion')): ?> data-accordion="false" <?php endif; ?>>
                <?php $role = Auth::check() ? Auth::user()->role : null; ?>

                <?php if($role === 'dokter'): ?>
                    
                    <li class="nav-item">
                        <a href="<?php echo e(route('periksa.index')); ?>"
                            class="nav-link <?php echo e(request()->is('dokter/periksa*') ? 'active' : ''); ?>">
                            <i class="nav-icon fas fa-notes-medical"></i>
                            <p>Data Periksa</p>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="<?php echo e(route('obat.index')); ?>"
                            class="nav-link <?php echo e(request()->is('dokter/obat*') ? 'active' : ''); ?>">
                            <i class="nav-icon fas fa-pills"></i>
                            <p>Data Obat</p>
                        </a>
                    </li>
                <?php elseif($role === 'pasien'): ?>
                    
                    <li class="nav-item">
                        <a href="<?php echo e(route('pasien.periksa.index')); ?>"
                            class="nav-link <?php echo e(request()->is('pasien/periksa*') ? 'active' : ''); ?>">
                            <i class="nav-icon fas fa-stethoscope"></i>
                            <p>Periksa & Riwayat</p>
                        </a>
                    </li>
                <?php endif; ?>
                <li class="nav-item">
                    <a href="<?php echo e(route('logout')); ?>" class="nav-link"
                        onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                        <i class="nav-icon fas fa-sign-out-alt"></i>
                        <p>Logout</p>
                    </a>
                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                        <?php echo csrf_field(); ?>
                    </form>
                </li>
            </ul>
        </nav>
    </div>

</aside>
<?php /**PATH D:\Tugas Kuliah\Semester 6\Folder Baru\sistem_manajemen_kesehatan\resources\views/vendor/adminlte/partials/sidebar/left-sidebar.blade.php ENDPATH**/ ?>