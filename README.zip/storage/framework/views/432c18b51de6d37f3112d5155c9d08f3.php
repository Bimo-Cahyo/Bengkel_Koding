


<?php $__env->startSection('title', 'Edit Obat'); ?>
<?php $__env->startSection('content_header'); ?>
    <div class="card-header">
        <a href="<?php echo e(route('obat.create')); ?>" class="btn btn-primary">Tambah Obat</a>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-body">
            <form action="<?php echo e(route('obat.update', $obat->id)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <div class="form-group">
                    <label for="nama">Nama obat</label>
                    <input type="text" name="name_obat" id="nama" placeholder="Nama obat" class="form-control"
                        value="<?php echo e($obat->name_obat); ?>" required>
                </div>
                
                <div class="form-group">
                    <label for="kemasan">Kemasan</label>
                    <?php if (isset($component)) { $__componentOriginal377f5828c1076ae12e071b1688061877 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal377f5828c1076ae12e071b1688061877 = $attributes; } ?>
<?php $component = JeroenNoten\LaravelAdminLte\View\Components\Form\Select::resolve(['name' => 'kemasan'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('adminlte-select'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\JeroenNoten\LaravelAdminLte\View\Components\Form\Select::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                        <option value="Sachet" <?php echo e($obat->kemasan === 'pill' ? 'selected' : ''); ?>>Pill</option>
                        <option value="Sachet" <?php echo e($obat->kemasan === 'sachet' ? 'selected' : ''); ?>>Sachet</option>
                        <option value="Sachet" <?php echo e($obat->kemasan === 'botol' ? 'selected' : ''); ?>>Botol</option>
                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal377f5828c1076ae12e071b1688061877)): ?>
<?php $attributes = $__attributesOriginal377f5828c1076ae12e071b1688061877; ?>
<?php unset($__attributesOriginal377f5828c1076ae12e071b1688061877); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal377f5828c1076ae12e071b1688061877)): ?>
<?php $component = $__componentOriginal377f5828c1076ae12e071b1688061877; ?>
<?php unset($__componentOriginal377f5828c1076ae12e071b1688061877); ?>
<?php endif; ?>
                </div>
                <div class="form-group">
                    <label for="harga">Harga</label>
                    <input type="number" name="harga" id="harga" placeholder="Harga obat" class="form-control"
                        value="<?php echo e($obat->harga); ?>" required>
                </div>
                <div class="wrapper d-flex justify-content-end" style="gap: 10px;">
                    <button type="submit" class="btn btn-success">Ubah</button>
                    <a href="<?php echo e(route('obat.index')); ?>" class="btn btn-secondary">Kembali</a>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Tugas Kuliah\Semester 6\Folder Baru\sistem_manajemen_kesehatan\resources\views/dokter/obat/edit.blade.php ENDPATH**/ ?>