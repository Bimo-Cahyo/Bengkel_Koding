<?php $__env->startSection('auth_body'); ?>
<div class="row justify-content-center">
    
    <div class="col-12 text-center mb-4">
        <h3 class="mb-1">
            Selamat Datang di <strong>SISMENKES</strong>
        </h3>
        <p class="text-muted mb-0">Silakan login untuk melanjutkan</p>
    </div>

    
    <div class="col-md-8 d-flex align-items-center justify-content-center">
        <div class="w-100 p-4">
            <form action="<?php echo e(route('login')); ?>" method="post" class="w-100">
                <?php echo csrf_field(); ?>

                
                <div class="mb-4">
                    <label for="email" class="form-label">Email</label>
                    <input 
                        type="email" 
                        name="email" 
                        id="email"
                        class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                        placeholder="Masukkan email" 
                        value="<?php echo e(old('email')); ?>" 
                        required 
                        autofocus
                    >
                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback">
                            <?php echo e($message); ?>

                        </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                
                <div class="mb-4">
                    <label for="password" class="form-label">Password</label>
                    <input 
                        type="password" 
                        name="password" 
                        id="password"
                        class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                        placeholder="Masukkan password" 
                        required
                    >
                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback">
                            <?php echo e($message); ?>

                        </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                
                <div class="mb-4 form-check">
                    <input 
                        type="checkbox" 
                        name="remember" 
                        class="form-check-input" 
                        id="remember"
                    >
                    <label class="form-check-label" for="remember">Ingat saya</label>
                </div>

                
                <div class="d-grid mb-3">
                    <button type="submit" class="btn btn-info btn-lg">
                        <i class="fas fa-sign-in-alt mr-1"></i> Login
                    </button>
                </div>
            </form>

            
            <div class="text-center small">
                <a href="<?php echo e(route('password.request')); ?>">Lupa password?</a> |
                <a href="<?php echo e(route('register')); ?>">Daftar akun baru</a>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::auth.auth-page', ['auth_type' => 'login'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Tugas Kuliah\Semester 6\Folder Baru\sistem_manajemen_kesehatan\resources\views/vendor/adminlte/auth/login.blade.php ENDPATH**/ ?>