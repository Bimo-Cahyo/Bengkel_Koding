<footer class="main-footer text-center">
    <strong>© <?php echo e(date('Y')); ?> Akhmad Haris</strong> - All rights reserved.
    <div class="float-right d-none d-sm-inline-block">
        <b>Version</b> 1.0.0
    </div>
</footer>
<?php /**PATH D:\Tugas Kuliah\Semester 6\Folder Baru\sistem_manajemen_kesehatan\resources\views/vendor/adminlte/partials/footer/footer.blade.php ENDPATH**/ ?>